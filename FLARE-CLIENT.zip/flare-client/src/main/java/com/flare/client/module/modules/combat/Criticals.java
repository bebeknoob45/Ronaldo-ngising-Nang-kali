package com.flare.client.module.modules.combat;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.AttackEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.ModeSetting;
import com.flare.client.util.PacketUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;

public class Criticals extends Module {
    private final ModeSetting mode = mode("Mode", "Packet", "Packet", "NCP", "Jump");
    public Criticals() { super("Criticals", "Forces critical hits when you attack.", Category.COMBAT); }

    @Subscribe
    private void onAttack(AttackEvent e) {
        var p = mc.player;
        if (p == null || !(e.target instanceof LivingEntity) || !p.isOnGround() || p.isTouchingWater() || p.isInLava() || p.isClimbing() || p.hasVehicle() || p.hasStatusEffect(StatusEffects.BLINDNESS)) return;
        double x = p.getX(), y = p.getY(), z = p.getZ();
        switch (mode.get()) {
            case "Packet" -> { PacketUtil.pos(x, y + 0.0625, z, false); PacketUtil.pos(x, y, z, false); }
            case "NCP" -> { PacketUtil.pos(x, y + 0.11, z, false); PacketUtil.pos(x, y + 0.1100013579, z, false); PacketUtil.pos(x, y + 0.0000013579, z, false); }
            case "Jump" -> p.jump();
        }
    }
}
