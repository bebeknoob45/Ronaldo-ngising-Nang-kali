package com.flare.client.event.events;
import com.flare.client.event.Event;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
public class Render3DEvent extends Event {
    public final Matrix4f view; public final Camera camera; public final Vec3d cam; public final float delta;
    public Render3DEvent(Matrix4f view, Camera camera, float delta) {
        // The game may already have its own view matrix loaded as model-view when this event fires (it would be applied twice).
        // Cancel it out so our camera-space coordinates always land exactly where intended.
        Matrix4f fixed = new Matrix4f(view);
        try { fixed = new Matrix4f(RenderSystem.getModelViewMatrix()).invert().mul(view); } catch (Throwable ignored) {}
        this.view = fixed; this.camera = camera; this.cam = camera.getPos(); this.delta = delta;
    }
}
