package com.flare.client.mixin;

import com.flare.client.FlareClient;
import com.flare.client.module.modules.combat.Reach;
import com.flare.client.module.modules.movement.Phase;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {
    @Inject(method = "getEntityInteractionRange", at = @At("RETURN"), cancellable = true, require = 0)
    private void flare$reach(CallbackInfoReturnable<Double> cir) {
        if ((Object) this != MinecraftClient.getInstance().player || FlareClient.modules == null) return;
        Reach r = FlareClient.modules.get(Reach.class);
        if (r != null && r.isEnabled()) cir.setReturnValue(r.range());
    }

    @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;isSpectator()Z", ordinal = 0), require = 0)
    private boolean flare$noclip(PlayerEntity self) {
        if (self == MinecraftClient.getInstance().player && FlareClient.modules != null) {
            Phase p = FlareClient.modules.get(Phase.class);
            if (p != null && p.isNoClip()) return true;
        }
        return self.isSpectator();
    }
}
