package com.flare.client.module.modules.render;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.MotionEvent;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.RotationManager;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;

/** Detaches the camera from your body. Your real player stays still and the server keeps seeing the old position/rotation. */
public class Freecam extends Module {
    private final NumberSetting speed = num("Speed", 1.0, 0.1, 5.0, 0.1);
    private final BoolSetting restoreRotation = bool("Restore Rotation", true);
    private CamEntity cam; private Vec3d saved; private float sy, sp;

    public static class CamEntity extends OtherClientPlayerEntity {
        public CamEntity(ClientWorld w, GameProfile p) { super(w, p); }
        @Override public float getYaw(float d) { return MinecraftClient.getInstance().player.getYaw(); }
        @Override public float getPitch(float d) { return MinecraftClient.getInstance().player.getPitch(); }
    }

    public Freecam() { super("Freecam", "Fly your camera around while your body stays put.", Category.RENDER); }

    @Override protected void onEnable() {
        if (mc.player == null || mc.world == null) { setEnabled(false, false); return; }
        saved = mc.player.getPos(); sy = mc.player.getYaw(); sp = mc.player.getPitch();
        cam = new CamEntity(mc.world, mc.player.getGameProfile());
        cam.refreshPositionAndAngles(saved.x, saved.y, saved.z, sy, sp);
        mc.setCameraEntity(cam);
    }

    @Override protected void onDisable() {
        if (mc.player != null) {
            mc.setCameraEntity(mc.player);
            if (restoreRotation.is()) { mc.player.setYaw(sy); mc.player.setPitch(sp); }
        }
        cam = null;
    }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        if (mc.player == null || mc.world == null || cam == null) { if (mc.player == null) setEnabled(false, false); return; }
        mc.player.setVelocity(Vec3d.ZERO);
        RotationManager.INSTANCE.rotate(sy, sp, 1); // server keeps seeing the original look direction
        float yaw = mc.player.getYaw(), pitch = mc.player.getPitch();
        Vec3d look = Vec3d.fromPolar(pitch, yaw), left = new Vec3d(Math.cos(Math.toRadians(yaw)), 0, Math.sin(Math.toRadians(yaw)));
        double f = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
        double s = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
        double u = (mc.options.jumpKey.isPressed() ? 1 : 0) - (mc.options.sneakKey.isPressed() ? 1 : 0);
        Vec3d v = look.multiply(f).add(left.multiply(s)).add(0, u, 0);
        if (v.lengthSquared() > 1e-6) v = v.normalize().multiply(speed.d() * (mc.options.sprintKey.isPressed() ? 2 : 1));
        cam.prevX = cam.getX(); cam.prevY = cam.getY(); cam.prevZ = cam.getZ();
        cam.setPosition(cam.getX() + v.x, cam.getY() + v.y, cam.getZ() + v.z);
    }

    /** Keep the real body exactly where it was before the packets are built. */
    @Subscribe
    private void onMotion(MotionEvent e) {
        if (!e.pre || mc.player == null || saved == null || cam == null) return;
        mc.player.setPosition(saved.x, saved.y, saved.z);
        mc.player.setVelocity(Vec3d.ZERO);
    }
}
