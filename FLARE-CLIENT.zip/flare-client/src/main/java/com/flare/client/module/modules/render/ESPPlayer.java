package com.flare.client.module.modules.render;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.Render3DEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class ESPPlayer extends Module {
    private final BoolSetting box3d = bool("3D", true), tracers = bool("Tracer", true), fill = bool("Fill", true),
            self = bool("Self (3rd person)", false), invisible = bool("Invisible", true), friends = bool("Friends Green", true);
    private final ModeSetting colorMode = mode("Color Mode", "Static", "Static", "Health", "Distance");
    private final ColorSetting color = color("Color", 0xFF6B00), tracerColor = color("Tracer Color", 0xFFFFFF);
    private final NumberSetting range = num("Range", 128, 16, 256, 8);
    public ESPPlayer() { super("ESP Player", "Boxes and tracers on players.", Category.RENDER); }

    @Override public String getSuffix() { return ""; }

    @Subscribe
    private void onRender(Render3DEvent e) {
        if (mc.world == null || mc.player == null) return;
        Vec3d start = e.cam.add(Vec3d.fromPolar(e.camera.getPitch(), e.camera.getYaw()).multiply(0.5));
        Render3D.begin(false);
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player && (!self.is() || mc.options.getPerspective().isFirstPerson())) continue;
            if (p.isSpectator() || (p.isInvisible() && !invisible.is())) continue;
            double d = mc.player.distanceTo(p); if (d > range.d()) continue;
            int col;
            if (friends.is() && CombatUtil.isFriend(p)) col = 0xFF55FF55;
            else if (colorMode.is("Health")) col = ColorUtil.lerp(0xFFFF3030, 0xFF30FF30, Math.min(1f, (p.getHealth() + p.getAbsorptionAmount()) / 20f));
            else if (colorMode.is("Distance")) col = ColorUtil.lerp(0xFFFF6B00, 0xFFFFFFFF, (float) Math.min(1, d / 60.0));
            else col = color.getColor() | 0xFF000000;
            Vec3d lp = p.getLerpedPos(e.delta);
            if (box3d.is()) Render3D.box(e, p.getBoundingBox().offset(lp.subtract(p.getPos())), col, fill.is(), true);
            if (tracers.is()) Render3D.line(e, start, lp.add(0, p.getHeight() / 2, 0), p == mc.player ? col : (colorMode.is("Static") ? tracerColor.getColor() | 0xFF000000 : col));
        }
        Render3D.end();
    }
}
