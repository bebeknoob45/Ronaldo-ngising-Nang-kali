package com.flare.client.event.events;
import com.flare.client.event.Event;
import net.minecraft.network.packet.Packet;
public class PacketEvent {
    public static class Send extends Event { public final Packet<?> packet; public Send(Packet<?> p) { packet = p; } }
    public static class Receive extends Event { public final Packet<?> packet; public Receive(Packet<?> p) { packet = p; } }
}
