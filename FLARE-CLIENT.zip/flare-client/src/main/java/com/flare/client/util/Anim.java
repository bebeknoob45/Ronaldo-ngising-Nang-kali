package com.flare.client.util;
/** Frame-rate independent exponential smoothing. */
public class Anim {
    public float value; private final float speed; private long last = System.nanoTime();
    public Anim(float init, float speed) { value = init; this.speed = speed; }
    public float update(float target) {
        long n = System.nanoTime(); float dt = Math.min(0.1f, (n - last) / 1e9f); last = n;
        value += (target - value) * (1f - (float) Math.exp(-speed * dt));
        if (Math.abs(target - value) < 0.002f) value = target;
        return value;
    }
    public float get() { return value; }
    public void set(float v) { value = v; }
}
