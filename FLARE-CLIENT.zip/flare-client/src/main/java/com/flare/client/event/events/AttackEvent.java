package com.flare.client.event.events;
import com.flare.client.event.Event;
import net.minecraft.entity.Entity;
public class AttackEvent extends Event {
    public final Entity target;
    public AttackEvent(Entity t) { target = t; }
}
