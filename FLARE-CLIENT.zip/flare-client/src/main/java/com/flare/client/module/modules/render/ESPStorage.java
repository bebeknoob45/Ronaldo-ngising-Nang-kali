package com.flare.client.module.modules.render;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.Render3DEvent;
import com.flare.client.event.events.TickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.*;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;
import java.util.*;

public class ESPStorage extends Module {
    private record Found(BlockPos pos, int color) {}
    private static final Map<String, Integer> SHULKER = new HashMap<>();
    static {
        SHULKER.put("white", 0xFFFFFF); SHULKER.put("orange", 0xF9801D); SHULKER.put("magenta", 0xC74EBD); SHULKER.put("light_blue", 0x3AB3DA);
        SHULKER.put("yellow", 0xFED83D); SHULKER.put("lime", 0x80C71F); SHULKER.put("pink", 0xF38BAA); SHULKER.put("gray", 0x474F52);
        SHULKER.put("light_gray", 0x9D9D97); SHULKER.put("cyan", 0x169C9C); SHULKER.put("purple", 0x8932B8); SHULKER.put("blue", 0x3C44AA);
        SHULKER.put("brown", 0x835432); SHULKER.put("green", 0x5E7C16); SHULKER.put("red", 0xB02E26); SHULKER.put("black", 0x2B2B30);
    }

    private final BoolSetting box3d = bool("3D", true), tracers = bool("Tracer", false), fill = bool("Fill", true);
    private final BoolSetting chest = bool("Chest (Brown)", true), trapped = bool("Trapped Chest (Orange)", true), barrel = bool("Barrel (Brown)", true),
            ender = bool("Ender Chest (Dark Green)", true), shulker = bool("Shulker Boxes (by colour)", true), hopper = bool("Hopper (Gray)", false),
            dropper = bool("Dropper (Gray)", false), dispenser = bool("Dispenser (Gray)", false), furnace = bool("Furnace (Dark Gray)", false),
            blast = bool("Blast Furnace (Dark Gray)", false), smoker = bool("Smoker (Brown/Gray)", false), bookshelf = bool("Chiseled Bookshelf (Brown)", false),
            crafter = bool("Crafter (Orange/Gray)", false);
    private final NumberSetting range = num("Range", 96, 16, 256, 8);
    private final List<Found> found = new ArrayList<>();
    private int tick;

    public ESPStorage() { super("ESP Storage", "Colour-coded boxes on chests, barrels, shulkers, hoppers and more.", Category.RENDER); }
    @Override public String getSuffix() { return ""; }
    @Override protected void onEnable() { tick = 0; }
    @Override protected void onDisable() { found.clear(); }

    private int colorFor(String id) {
        if (id.equals("chest")) return chest.is() ? 0x8B5A2B : -1;
        if (id.equals("trapped_chest")) return trapped.is() ? 0xFF8C00 : -1;
        if (id.equals("barrel")) return barrel.is() ? 0xA0522D : -1;
        if (id.equals("ender_chest")) return ender.is() ? 0x0B5D3B : -1;
        if (id.equals("shulker_box")) return shulker.is() ? SHULKER.get("purple") : -1;
        if (id.endsWith("_shulker_box")) { if (!shulker.is()) return -1; Integer c = SHULKER.get(id.substring(0, id.length() - 12)); return c == null ? 0x8932B8 : c; }
        if (id.equals("hopper")) return hopper.is() ? 0x808080 : -1;
        if (id.equals("dropper")) return dropper.is() ? 0x909090 : -1;
        if (id.equals("dispenser")) return dispenser.is() ? 0x707070 : -1;
        if (id.equals("furnace")) return furnace.is() ? 0x4A4A4A : -1;
        if (id.equals("blast_furnace")) return blast.is() ? 0x3C3C44 : -1;
        if (id.equals("smoker")) return smoker.is() ? 0x8A7560 : -1;
        if (id.equals("chiseled_bookshelf")) return bookshelf.is() ? 0x9C6B3F : -1;
        if (id.equals("crafter")) return crafter.is() ? 0xC98A4B : -1;
        return -1;
    }

    @Subscribe
    private void onTick(TickEvent.Post e) {
        if (++tick % 10 != 1 || mc.world == null || mc.player == null) return;
        found.clear();
        int cr = Math.min(10, mc.options.getViewDistance().getValue()); ChunkPos c = mc.player.getChunkPos(); double r2 = range.d() * range.d();
        for (int x = -cr; x <= cr; x++) for (int z = -cr; z <= cr; z++) {
            WorldChunk ch = mc.world.getChunkManager().getWorldChunk(c.x + x, c.z + z);
            if (ch == null) continue;
            for (BlockEntity be : ch.getBlockEntities().values()) {
                if (mc.player.squaredDistanceTo(be.getPos().toCenterPos()) > r2) continue;
                int col = colorFor(Registries.BLOCK.getId(be.getCachedState().getBlock()).getPath());
                if (col >= 0) found.add(new Found(be.getPos(), 0xFF000000 | col));
            }
        }
    }

    @Subscribe
    private void onRender(Render3DEvent e) {
        if (found.isEmpty()) return;
        Vec3d start = e.cam.add(Vec3d.fromPolar(e.camera.getPitch(), e.camera.getYaw()).multiply(0.5));
        Render3D.begin(false);
        for (Found f : found) {
            if (box3d.is()) Render3D.box(e, new Box(f.pos()).contract(0.05), f.color(), fill.is(), true);
            if (tracers.is()) Render3D.line(e, start, Vec3d.ofCenter(f.pos()), f.color());
        }
        Render3D.end();
    }
}
