package com.flare.client.gui;

import com.flare.client.FlareClient;
import com.flare.client.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;

/** Shared header: logo + tabs (Modules / HUD Editor / Configs). */
public final class TopBar {
    private static final String[] TABS = {"MODULES", "HUD EDITOR", "CONFIGS"};
    private static final Anim[] hov = {new Anim(0, 18), new Anim(0, 18), new Anim(0, 18)};

    public static void render(DrawContext ctx, int mx, int my, int sw, int active) {
        Draw.rrect(ctx, 6, 4, sw - 12, 24, 4, 0xF00A0A0A);
        Draw.gradH(ctx, 6, 26, sw - 12, 2, ColorUtil.ORANGE, ColorUtil.alpha(ColorUtil.ORANGE2, 30));
        Draw.glow(ctx, 6, 4, sw - 12, 24, 4, ColorUtil.ORANGE, 0.35f);
        Draw.textScaled(ctx, "FLARE", 14, 9, 1.4f, ColorUtil.flame(0) | 0xFF000000, true);
        Draw.text(ctx, "CLIENT", 14 + Draw.width("FLARE") * 1.4f + 4, 13, 0xFFFFFFFF, true);
        float x = sw - 12;
        for (int i = TABS.length - 1; i >= 0; i--) {
            float w = Draw.width(TABS[i]) + 14; x -= w + 4;
            boolean h = Draw.hover(mx, my, x, 8, w, 16);
            float t = hov[i].update(h || i == active ? 1 : 0);
            Draw.rrect(ctx, x, 8, w, 16, 3, ColorUtil.lerp(0xFF161616, 0xFFFF6B00, i == active ? 1f : t * 0.5f));
            Draw.text(ctx, TABS[i], x + 7, 12, i == active ? 0xFF0A0A0A : 0xFFFFFFFF, false);
        }
    }

    /** @return screen to open or null */
    public static Screen click(double mx, double my, int sw, int active) {
        float x = sw - 12;
        for (int i = TABS.length - 1; i >= 0; i--) {
            float w = Draw.width(TABS[i]) + 14; x -= w + 4;
            if (Draw.hover(mx, my, x, 8, w, 16) && i != active) return i == 0 ? new ClickGuiScreen() : i == 1 ? new HudEditorScreen() : new ConfigScreen();
        }
        return null;
    }
}
