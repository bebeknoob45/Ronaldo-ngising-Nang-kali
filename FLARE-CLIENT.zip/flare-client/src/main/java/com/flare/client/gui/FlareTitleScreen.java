package com.flare.client.gui;

import com.flare.client.FlareClient;
import com.flare.client.util.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import java.util.Random;

public class FlareTitleScreen extends Screen {
    private static final String[] BTN = {"SINGLEPLAYER", "MULTIPLAYER", "CUSTOM IDENTITY", "OPTIONS", "QUIT GAME"};
    private final Anim[] hov = {new Anim(0, 16), new Anim(0, 16), new Anim(0, 16), new Anim(0, 16), new Anim(0, 16)};
    private final float[][] embers = new float[90][5];
    private final long start = System.currentTimeMillis();

    public FlareTitleScreen() {
        super(Text.literal("FLARE CLIENT"));
        Random r = new Random();
        for (float[] e : embers) { e[0] = r.nextFloat(); e[1] = r.nextFloat(); e[2] = 0.03f + r.nextFloat() * 0.08f; e[3] = 1 + r.nextInt(3); e[4] = r.nextFloat(); }
    }

    @Override public boolean shouldCloseOnEsc() { return false; }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        Draw.alpha = 1f;
        ctx.fill(0, 0, width, height, 0xFF0A0A0A);
        ctx.fillGradient(0, height / 3, width, height, 0x00FF6B00, 0x55FF6B00);
        float pulse = (float) (Math.sin(System.currentTimeMillis() / 700.0) * 0.5 + 0.5);
        for (float[] e : embers) {
            e[1] -= e[2] * 0.016f; if (e[1] < -0.02f) { e[1] = 1.02f; }
            float x = e[0] * width + (float) Math.sin(System.currentTimeMillis() / 1000.0 + e[4] * 9) * 8;
            Draw.rect(ctx, x, e[1] * height, e[3], e[3], ColorUtil.alpha(e[4] > 0.5f ? ColorUtil.ORANGE : ColorUtil.ORANGE2, (int) (60 + 150 * e[1])));
        }
        int cx = width / 2, ty = height / 2 - 92;
        float sc = 4f, tw = Draw.width("FLARE") * sc;
        Draw.glow(ctx, cx - tw / 2f, ty, tw, 32, 6, ColorUtil.ORANGE, 0.5f + pulse * 0.4f);
        Draw.textScaled(ctx, "FLARE", cx - tw / 2f, ty, sc, ColorUtil.flame(0) | 0xFF000000, true);
        String sub = "C L I E N T";
        Draw.textScaled(ctx, sub, cx - Draw.width(sub) * 1.5f / 2f, ty + 36, 1.5f, 0xFFFFFFFF, true);
        Draw.gradH(ctx, cx - 60, ty + 52, 120, 2, ColorUtil.ORANGE, ColorUtil.ORANGE2);
        for (int i = 0; i < BTN.length; i++) {
            float bw = 150, bh = 20, bx = cx - bw / 2f, by = height / 2f - 22 + i * 24;
            float t = hov[i].update(Draw.hover(mx, my, bx, by, bw, bh) ? 1 : 0);
            Draw.glow(ctx, bx, by, bw, bh, 3, ColorUtil.ORANGE, t);
            Draw.rrect(ctx, bx, by, bw, bh, 3, ColorUtil.lerp(0xFF141414, 0xFFFF6B00, t));
            Draw.text(ctx, BTN[i], bx + (bw - Draw.width(BTN[i])) / 2f, by + 6, ColorUtil.lerp(0xFFFFFFFF, 0xFF0A0A0A, t), false);
        }
        Draw.text(ctx, "FLARE CLIENT " + FlareClient.VERSION + "  |  Minecraft 1.21.4  |  Right Shift = ClickGUI", 6, height - 12, 0xFF777777, false);
    }

    @Override public boolean mouseClicked(double mx, double my, int btn) {
        int cx = width / 2;
        for (int i = 0; i < BTN.length; i++) {
            float bw = 150, bh = 20, bx = cx - bw / 2f, by = height / 2f - 22 + i * 24;
            if (btn == 0 && Draw.hover(mx, my, bx, by, bw, bh)) {
                switch (i) {
                    case 0 -> client.setScreen(new SelectWorldScreen(this));
                    case 1 -> client.setScreen(new MultiplayerScreen(this));
                    case 2 -> client.setScreen(new IdentityScreen(this));
                    case 3 -> client.setScreen(new OptionsScreen(this, client.options));
                    default -> client.scheduleStop();
                }
                return true;
            }
        }
        return false;
    }
}
