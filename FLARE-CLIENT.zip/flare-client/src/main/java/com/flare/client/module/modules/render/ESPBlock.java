package com.flare.client.module.modules.render;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.Render3DEvent;
import com.flare.client.event.events.TickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.*;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import java.util.*;

/** Highlights chosen blocks (ores, spawners, ...) plus your own custom list (/espblock add <id>). */
public class ESPBlock extends Module {
    private record Preset(BoolSetting on, int color, Block[] blocks) {}
    private record Found(BlockPos pos, int color) {}

    private final BoolSetting custom = bool("Custom", true), box3d = bool("3D", true), tracers = bool("Tracer", false), fill = bool("Fill", true),
            crystals = bool("Crystals", true), items = bool("Items", false);
    private final ColorSetting customColor = color("Custom Color", 0xFF6B00);
    private final NumberSetting range = num("Range", 20, 8, 48, 4);
    private final List<Preset> presets = new ArrayList<>();
    private final LinkedHashMap<String, Block> customBlocks = new LinkedHashMap<>();
    private final List<Found> found = new ArrayList<>();
    private int tick;

    public ESPBlock() {
        super("ESP Block", "Highlights ores and other blocks, plus your custom block list.", Category.RENDER);
        preset("Diamond", true, 0x3DE0E8, Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE);
        preset("Ancient Debris", true, 0x8B4A2B, Blocks.ANCIENT_DEBRIS);
        preset("Emerald", false, 0x17DD62, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE);
        preset("Gold", false, 0xFFD700, Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.NETHER_GOLD_ORE);
        preset("Iron", false, 0xD8AF93, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE);
        preset("Coal", false, 0x555555, Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE);
        preset("Copper", false, 0xE0774F, Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE);
        preset("Redstone", false, 0xFF2020, Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE);
        preset("Lapis", false, 0x2850D8, Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE);
        preset("Nether Quartz", false, 0xF0F0F0, Blocks.NETHER_QUARTZ_ORE);
        preset("Spawner", false, 0xAA00FF, Blocks.SPAWNER);
        preset("Obsidian", false, 0x3A1F6B, Blocks.OBSIDIAN, Blocks.CRYING_OBSIDIAN);
        preset("Beacon", false, 0x80FFFF, Blocks.BEACON);
    }

    private void preset(String name, boolean def, int rgb, Block... b) { presets.add(new Preset(bool(name, def), 0xFF000000 | rgb, b)); }

    @Override public void onInit() {
        ClientCommandRegistrationCallback.EVENT.register((d, r) -> d.register(ClientCommandManager.literal("espblock")
                .then(ClientCommandManager.literal("add").then(ClientCommandManager.argument("block", StringArgumentType.word()).executes(c -> {
                    String id = StringArgumentType.getString(c, "block"); Identifier i = Identifier.tryParse(id.contains(":") ? id : "minecraft:" + id);
                    if (i == null || !Registries.BLOCK.containsId(i)) { c.getSource().sendFeedback(Text.literal("Unknown block: " + id)); return 0; }
                    customBlocks.put(i.toString(), Registries.BLOCK.get(i)); c.getSource().sendFeedback(Text.literal("ESP Block: added " + i)); return 1; })))
                .then(ClientCommandManager.literal("remove").then(ClientCommandManager.argument("block", StringArgumentType.word()).executes(c -> {
                    String id = StringArgumentType.getString(c, "block"); customBlocks.remove(id.contains(":") ? id : "minecraft:" + id);
                    c.getSource().sendFeedback(Text.literal("ESP Block: removed " + id)); return 1; })))
                .then(ClientCommandManager.literal("clear").executes(c -> { customBlocks.clear(); c.getSource().sendFeedback(Text.literal("ESP Block: custom list cleared")); return 1; }))
                .then(ClientCommandManager.literal("list").executes(c -> { c.getSource().sendFeedback(Text.literal("Custom blocks: " + (customBlocks.isEmpty() ? "(none)" : String.join(", ", customBlocks.keySet())))); return 1; }))));
    }

    @Override public void onSave(JsonObject o) { JsonArray a = new JsonArray(); customBlocks.keySet().forEach(a::add); o.add("custom", a); }
    @Override public void onLoad(JsonObject o) {
        customBlocks.clear();
        if (o.has("custom")) o.getAsJsonArray("custom").forEach(x -> { Identifier i = Identifier.tryParse(x.getAsString()); if (i != null && Registries.BLOCK.containsId(i)) customBlocks.put(i.toString(), Registries.BLOCK.get(i)); });
    }

    @Subscribe
    private void onTick(TickEvent.Post e) { if (++tick % 20 == 1) scan(); }
    @Override protected void onEnable() { tick = 0; }
    @Override protected void onDisable() { found.clear(); }

    private void scan() {
        found.clear();
        if (mc.world == null || mc.player == null) return;
        Map<Block, Integer> map = new HashMap<>();
        for (Preset p : presets) if (p.on().is()) for (Block b : p.blocks()) map.put(b, p.color());
        if (custom.is()) for (Block b : customBlocks.values()) map.put(b, customColor.getColor() | 0xFF000000);
        if (map.isEmpty()) return;
        int r = range.i(); BlockPos o = mc.player.getBlockPos();
        int y0 = Math.max(mc.world.getBottomY(), o.getY() - r), y1 = Math.min(mc.world.getBottomY() + mc.world.getHeight() - 1, o.getY() + r);
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int x = o.getX() - r; x <= o.getX() + r; x++) for (int z = o.getZ() - r; z <= o.getZ() + r; z++) {
            if (!mc.world.getChunkManager().isChunkLoaded(x >> 4, z >> 4)) continue;
            for (int y = y0; y <= y1; y++) {
                m.set(x, y, z);
                Integer c = map.get(mc.world.getBlockState(m).getBlock());
                if (c != null) { found.add(new Found(m.toImmutable(), c)); if (found.size() >= 800) return; }
            }
        }
    }

    @Subscribe
    private void onRender(Render3DEvent e) {
        if (mc.world == null || mc.player == null) return;
        Vec3d start = e.cam.add(Vec3d.fromPolar(e.camera.getPitch(), e.camera.getYaw()).multiply(0.5));
        Render3D.begin(false);
        int lines = 0;
        for (Found f : found) {
            if (box3d.is()) Render3D.box(e, new Box(f.pos()), f.color(), fill.is(), true);
            if (tracers.is() && lines++ < 40) Render3D.line(e, start, Vec3d.ofCenter(f.pos()), f.color());
        }
        if (crystals.is() || items.is()) for (Entity en : mc.world.getEntities()) {
            int col;
            if (en instanceof EndCrystalEntity && crystals.is()) col = 0xFFFF8C00; else if (en instanceof ItemEntity && items.is()) col = 0xFFFFFFFF; else continue;
            if (mc.player.squaredDistanceTo(en) > 96 * 96) continue;
            Render3D.box(e, en.getBoundingBox().offset(en.getLerpedPos(e.delta).subtract(en.getPos())), col, fill.is(), true);
        }
        Render3D.end();
    }
}
