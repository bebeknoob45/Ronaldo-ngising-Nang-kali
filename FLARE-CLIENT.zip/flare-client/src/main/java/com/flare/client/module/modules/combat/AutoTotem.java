package com.flare.client.module.modules.combat;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.NumberSetting;
import com.flare.client.util.InventoryUtil;
import net.minecraft.item.Items;

public class AutoTotem extends Module {
    private final NumberSetting health = num("Health", 20, 1, 20, 1);
    private final NumberSetting delay = num("Delay", 1, 0, 10, 1);
    private int tick;
    public AutoTotem() { super("AutoTotem", "Keeps a Totem of Undying in your offhand.", Category.COMBAT); }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        if (mc.player == null || !InventoryUtil.playerHandlerOpen()) return;
        if (++tick < delay.i()) return;
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        if (mc.player.getHealth() + mc.player.getAbsorptionAmount() > health.d()) return;
        int slot = InventoryUtil.findInventory(s -> s.isOf(Items.TOTEM_OF_UNDYING));
        if (slot < 0) return;
        InventoryUtil.swapWithOffhand(slot); tick = 0;
    }
}
