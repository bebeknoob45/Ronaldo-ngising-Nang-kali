package com.flare.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import java.util.function.Predicate;

public final class InventoryUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static int findHotbar(Predicate<ItemStack> p) {
        for (int i = 0; i < 9; i++) if (p.test(mc.player.getInventory().getStack(i))) return i;
        return -1;
    }
    /** Searches main inventory (9..35) first then hotbar; returns inventory index or -1. */
    public static int findInventory(Predicate<ItemStack> p) {
        for (int i = 9; i < 36; i++) if (p.test(mc.player.getInventory().getStack(i))) return i;
        for (int i = 0; i < 9; i++) if (p.test(mc.player.getInventory().getStack(i))) return i;
        return -1;
    }
    public static int slotId(int invIndex) { return invIndex < 9 ? invIndex + 36 : invIndex; }
    public static boolean playerHandlerOpen() { return mc.player.currentScreenHandler == mc.player.playerScreenHandler; }

    public static void swapWithOffhand(int invIndex) {
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slotId(invIndex), 40, SlotActionType.SWAP, mc.player);
    }
    public static void swapWithHotbar(int invIndex, int hotbar) {
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slotId(invIndex), hotbar, SlotActionType.SWAP, mc.player);
    }
    public static void click(int slotId, int button, SlotActionType t) {
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slotId, button, t, mc.player);
    }

    public static EquipmentSlot armorSlot(ItemStack s) {
        if (s.isEmpty()) return null;
        EquippableComponent e = s.get(DataComponentTypes.EQUIPPABLE);
        if (e == null) return null;
        EquipmentSlot sl = e.slot();
        String id = Registries.ITEM.getId(s.getItem()).getPath();
        if (id.contains("elytra") || id.contains("pumpkin") || id.contains("head") || id.contains("skull")) return null;
        return (sl == EquipmentSlot.HEAD || sl == EquipmentSlot.CHEST || sl == EquipmentSlot.LEGS || sl == EquipmentSlot.FEET) ? sl : null;
    }
    public static float armorScore(ItemStack s) {
        if (s.isEmpty()) return 0;
        String id = Registries.ITEM.getId(s.getItem()).getPath();
        float t = id.contains("netherite") ? 6 : id.contains("diamond") ? 5 : id.contains("iron") ? 4 : id.contains("chainmail") ? 3
                : id.contains("golden") ? 2.5f : id.contains("turtle") ? 2.2f : id.contains("leather") ? 1 : 0.5f;
        if (s.getMaxDamage() > 0) t += 0.5f * (1f - s.getDamage() / (float) s.getMaxDamage());
        return t;
    }
}
