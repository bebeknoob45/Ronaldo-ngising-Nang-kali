package com.flare.client.module.modules.combat;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.gui.NotificationManager;
import com.flare.client.setting.*;
import com.flare.client.util.*;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class Surround extends Module {
    private final NumberSetting blocks = num("Blocks/Tick", 4, 1, 8, 1);
    private final BoolSetting rotate = bool("Rotate", false), center = bool("Center", true), support = bool("Support", true), disableJump = bool("Disable On Jump", true), swing = bool("Swing", true);
    public Surround() { super("Surround", "Surrounds your feet with obsidian.", Category.COMBAT); }

    @Override protected void onEnable() {
        if (mc.player == null || !center.is()) return;
        BlockPos b = mc.player.getBlockPos();
        Vec3d c = Vec3d.ofBottomCenter(b);
        mc.player.setPosition(c.x, mc.player.getY(), c.z);
        PacketUtil.pos(c.x, mc.player.getY(), c.z, mc.player.isOnGround());
    }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        if (mc.player == null) return;
        if (disableJump.is() && mc.options.jumpKey.isPressed() && !mc.player.isOnGround()) { setEnabled(false); return; }
        int slot = InventoryUtil.findHotbar(s -> s.isOf(Items.OBSIDIAN));
        if (slot < 0) { NotificationManager.push("Surround", "No obsidian in hotbar", false); setEnabled(false, false); return; }
        BlockPos feet = mc.player.getBlockPos(); int placed = 0;
        for (Direction d : Direction.Type.HORIZONTAL) {
            if (placed >= blocks.i()) break;
            BlockPos p = feet.offset(d);
            if (!mc.world.getBlockState(p).isReplaceable()) continue;
            if (support.is() && mc.world.getBlockState(p.down()).isReplaceable() && BlockUtil.place(p.down(), slot, rotate.is(), swing.is())) { placed++; continue; }
            if (BlockUtil.place(p, slot, rotate.is(), swing.is())) placed++;
        }
    }
}
