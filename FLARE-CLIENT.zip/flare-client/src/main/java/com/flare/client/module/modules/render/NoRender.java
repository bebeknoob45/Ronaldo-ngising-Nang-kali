package com.flare.client.module.modules.render;

import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.BoolSetting;

/** Overlay removal is implemented in the InGameHud / InGameOverlayRenderer / GameRenderer mixins. */
public class NoRender extends Module {
    public final BoolSetting fire = bool("Fire", true), nausea = bool("Nausea", true), overlays = bool("Pumpkin / Snow", true),
            water = bool("Underwater", false), wall = bool("In Wall", true), hurtCam = bool("Hurt Cam", false);
    public NoRender() { super("NoRender", "Removes annoying overlays.", Category.RENDER); }
}
