package com.flare.client.setting;
import com.google.gson.*;
public class KeybindSetting extends Setting<Integer> {
    public boolean listening;
    public KeybindSetting(String n, int key) { super(n, key); }
    public int key() { return value; }
    public JsonElement save() { return new JsonPrimitive(value); }
    public void load(JsonElement e) { value = e.getAsInt(); }
}
