package com.flare.client.module.modules.movement;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.ModeSetting;
import com.flare.client.util.MoveUtil;

public class Sprint extends Module {
    private final ModeSetting mode = mode("Mode", "Legit", "Legit", "Omni");
    public Sprint() { super("Sprint", "Automatically sprints. Omni sprints in every direction.", Category.MOVEMENT); }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        var p = mc.player; if (p == null || p.isSneaking() || p.getHungerManager().getFoodLevel() <= 6 || p.horizontalCollision) return;
        if (mode.is("Omni") ? MoveUtil.isMoving() : mc.options.forwardKey.isPressed()) p.setSprinting(true);
    }
}
