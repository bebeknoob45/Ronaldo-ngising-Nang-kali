package com.flare.client.mixin;

import com.flare.client.gui.FlareTitleScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen flare$title(Screen s) {
        return (s != null && s.getClass() == TitleScreen.class) ? new FlareTitleScreen() : s;
    }
    @Inject(method = "getWindowTitle", at = @At("RETURN"), cancellable = true, require = 0)
    private void flare$windowTitle(CallbackInfoReturnable<String> cir) { cir.setReturnValue("FLARE CLIENT | " + cir.getReturnValue()); }
}
