package com.flare.client.util;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.ShapeContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public final class BlockUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    /** Places a block at pos against any neighbouring solid face. slot = hotbar slot to use silently (-1 = held). */
    public static boolean place(BlockPos pos, int slot, boolean rotate, boolean swing) {
        if (!mc.world.getBlockState(pos).isReplaceable()) return false;
        if (!mc.world.canPlace(Blocks.STONE.getDefaultState(), pos, ShapeContext.absent())) return false;
        for (Direction d : Direction.values()) {
            BlockPos n = pos.offset(d); BlockState ns = mc.world.getBlockState(n);
            if (ns.isAir() || ns.isReplaceable() || !ns.getFluidState().isEmpty() || ns.getBlock() instanceof BlockWithEntity) continue;
            Direction face = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(n).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            if (mc.player.getEyePos().distanceTo(hit) > 5.0) continue;
            if (rotate) RotationManager.INSTANCE.snapTo(hit);
            PlayerInventory inv = mc.player.getInventory(); int prev = inv.selectedSlot;
            if (slot >= 0 && slot != prev) inv.selectedSlot = slot;
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hit, face, n, false));
            if (swing) mc.player.swingHand(Hand.MAIN_HAND);
            if (slot >= 0 && slot != prev) { inv.selectedSlot = prev; PacketUtil.send(new UpdateSelectedSlotC2SPacket(prev)); }
            return true;
        }
        return false;
    }
}
