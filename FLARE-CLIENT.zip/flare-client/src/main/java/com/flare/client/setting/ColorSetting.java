package com.flare.client.setting;
import com.flare.client.util.ColorUtil;
import com.google.gson.*;
import java.awt.Color;
public class ColorSetting extends Setting<Integer> {
    public float h, s, b; public int alpha = 255; public boolean rainbow;
    public ColorSetting(String n, int rgb) {
        super(n, rgb);
        float[] hsb = Color.RGBtoHSB((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255, null);
        h = hsb[0]; s = hsb[1]; b = hsb[2];
    }
    /** ARGB colour (rainbow aware). */
    public int getColor() {
        if (rainbow) return ColorUtil.rainbow(4f, 0f, 255);
        return (alpha << 24) | (Color.HSBtoRGB(h, s, b) & 0xFFFFFF);
    }
    public int getRgb() { return getColor() & 0xFFFFFF; }
    public JsonElement save() {
        JsonObject o = new JsonObject();
        o.addProperty("h", h); o.addProperty("s", s); o.addProperty("b", b); o.addProperty("a", alpha); o.addProperty("r", rainbow);
        return o;
    }
    public void load(JsonElement e) {
        JsonObject o = e.getAsJsonObject();
        h = o.get("h").getAsFloat(); s = o.get("s").getAsFloat(); b = o.get("b").getAsFloat();
        alpha = o.get("a").getAsInt(); rainbow = o.get("r").getAsBoolean();
    }
}
