package com.flare.client.event.events;
import com.flare.client.event.Event;
import net.minecraft.client.gui.DrawContext;
public class Render2DEvent extends Event {
    public final DrawContext ctx; public final float delta;
    public Render2DEvent(DrawContext ctx, float delta) { this.ctx = ctx; this.delta = delta; }
}
