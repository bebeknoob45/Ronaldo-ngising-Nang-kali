package com.flare.client.module.modules.client;

import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.SimpleOption;

/** Free FPS boost: lowers expensive video settings while enabled and restores your originals when disabled. */
public class FPSBoost extends Module {
    private final BoolSetting particles = bool("Minimal Particles", true), shadows = bool("No Entity Shadows", true), graphics = bool("Fast Graphics", true),
            clouds = bool("No Clouds", true), blend = bool("Biome Blend Off", true), entityDist = bool("Closer Entity Culling", true), unlimited = bool("Unlimited FPS", false),
            bob = bool("No View Bobbing", false);
    private final BoolSetting lowDist = bool("Lower Render Distance", false);
    private final NumberSetting dist = (NumberSetting) num("Render Distance", 8, 2, 16, 1).visibleIf(() -> lowDist.is());
    private boolean saved;
    private Object oParticles; private boolean oShadows, oBob; private GraphicsMode oGfx; private CloudRenderMode oClouds;
    private int oBlend, oView, oMaxFps; private double oEntity;

    public FPSBoost() { super("FPSBoost", "Boosts FPS by lowering heavy video settings (restored when turned off).", Category.CLIENT); }

    @Override protected void onEnable() {
        GameOptions o = mc.options; if (o == null) return;
        oParticles = o.getParticles().getValue(); oShadows = o.getEntityShadows().getValue(); oGfx = o.getGraphicsMode().getValue(); oClouds = o.getCloudRenderMode().getValue();
        oBlend = o.getBiomeBlendRadius().getValue(); oView = o.getViewDistance().getValue(); oMaxFps = o.getMaxFps().getValue(); oEntity = o.getEntityDistanceScaling().getValue(); oBob = o.getBobView().getValue();
        saved = true;
        if (particles.is()) setParticles(o, true);
        if (shadows.is()) o.getEntityShadows().setValue(false);
        if (graphics.is()) o.getGraphicsMode().setValue(GraphicsMode.FAST);
        if (clouds.is()) o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        if (blend.is()) o.getBiomeBlendRadius().setValue(0);
        if (entityDist.is()) o.getEntityDistanceScaling().setValue(0.5);
        if (unlimited.is()) o.getMaxFps().setValue(260);
        if (bob.is()) o.getBobView().setValue(false);
        if (lowDist.is()) o.getViewDistance().setValue(dist.i());
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private void setParticles(GameOptions o, boolean minimal) {
        try {
            SimpleOption opt = o.getParticles();
            if (minimal) { Class ec = ((Enum) opt.getValue()).getDeclaringClass(); opt.setValue(Enum.valueOf(ec, "MINIMAL")); }
            else if (oParticles != null) opt.setValue(oParticles);
        } catch (Throwable ignored) {}
    }

    @Override protected void onDisable() { restoreForExit(); }

    public void restoreForExit() {
        if (!saved || mc.options == null) return;
        GameOptions o = mc.options; saved = false;
        setParticles(o, false); o.getEntityShadows().setValue(oShadows); o.getGraphicsMode().setValue(oGfx); o.getCloudRenderMode().setValue(oClouds);
        o.getBiomeBlendRadius().setValue(oBlend); o.getViewDistance().setValue(oView); o.getMaxFps().setValue(oMaxFps); o.getEntityDistanceScaling().setValue(oEntity); o.getBobView().setValue(oBob);
    }
}
