package com.flare.client.util;

import com.flare.client.event.events.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/** Immediate-mode 3D helpers drawn after the world (through walls by default). */
public final class Render3D {
    public static void begin(boolean depth) {
        RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc();
        if (depth) RenderSystem.enableDepthTest(); else RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
    }
    public static void end() { RenderSystem.enableDepthTest(); RenderSystem.enableCull(); RenderSystem.disableBlend(); RenderSystem.lineWidth(1f); }

    private static void v(BufferBuilder b, Matrix4f m, float x, float y, float z, int c) { b.vertex(m, x, y, z).color(c); }

    public static void box(Render3DEvent e, Box bx, int color, boolean fill, boolean outline) {
        Matrix4f m = e.view;
        float x1 = (float) (bx.minX - e.cam.x), y1 = (float) (bx.minY - e.cam.y), z1 = (float) (bx.minZ - e.cam.z);
        float x2 = (float) (bx.maxX - e.cam.x), y2 = (float) (bx.maxY - e.cam.y), z2 = (float) (bx.maxZ - e.cam.z);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        if (fill) {
            int f = ColorUtil.alpha(color, 60);
            BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            v(b, m, x1, y1, z1, f); v(b, m, x2, y1, z1, f); v(b, m, x2, y1, z2, f); v(b, m, x1, y1, z2, f);
            v(b, m, x1, y2, z1, f); v(b, m, x1, y2, z2, f); v(b, m, x2, y2, z2, f); v(b, m, x2, y2, z1, f);
            v(b, m, x1, y1, z1, f); v(b, m, x1, y2, z1, f); v(b, m, x2, y2, z1, f); v(b, m, x2, y1, z1, f);
            v(b, m, x1, y1, z2, f); v(b, m, x2, y1, z2, f); v(b, m, x2, y2, z2, f); v(b, m, x1, y2, z2, f);
            v(b, m, x1, y1, z1, f); v(b, m, x1, y1, z2, f); v(b, m, x1, y2, z2, f); v(b, m, x1, y2, z1, f);
            v(b, m, x2, y1, z1, f); v(b, m, x2, y2, z1, f); v(b, m, x2, y2, z2, f); v(b, m, x2, y1, z2, f);
            BufferRenderer.drawWithGlobalProgram(b.end());
        }
        if (outline) {
            int o = ColorUtil.alpha(color, 255);
            BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
            float[][] c = {{x1, y1, z1}, {x2, y1, z1}, {x2, y1, z2}, {x1, y1, z2}, {x1, y2, z1}, {x2, y2, z1}, {x2, y2, z2}, {x1, y2, z2}};
            int[][] ed = {{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
            for (int[] k : ed) { v(b, m, c[k[0]][0], c[k[0]][1], c[k[0]][2], o); v(b, m, c[k[1]][0], c[k[1]][1], c[k[1]][2], o); }
            RenderSystem.lineWidth(1.8f);
            BufferRenderer.drawWithGlobalProgram(b.end());
        }
    }

    public static void line(Render3DEvent e, Vec3d a, Vec3d bb, int color) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        v(b, e.view, (float) (a.x - e.cam.x), (float) (a.y - e.cam.y), (float) (a.z - e.cam.z), color);
        v(b, e.view, (float) (bb.x - e.cam.x), (float) (bb.y - e.cam.y), (float) (bb.z - e.cam.z), color);
        RenderSystem.lineWidth(1.6f);
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    /** Camera-relative line (start already in camera space). */
    public static void lineFromCamera(Render3DEvent e, Vec3d camRel, Vec3d to, int color) {
        line(e, e.cam.add(camRel), to, color);
    }

    public static void fan(Render3DEvent e, Vec3d tip, double radius, double height, int segments, int color) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        v(b, e.view, (float) (tip.x - e.cam.x), (float) (tip.y + height - e.cam.y), (float) (tip.z - e.cam.z), color);
        for (int i = 0; i <= segments; i++) {
            double a = Math.PI * 2 * i / segments;
            v(b, e.view, (float) (tip.x + Math.cos(a) * radius - e.cam.x), (float) (tip.y - e.cam.y), (float) (tip.z + Math.sin(a) * radius - e.cam.z), ColorUtil.alpha(color, 120));
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }
}
