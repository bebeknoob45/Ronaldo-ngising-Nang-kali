package com.flare.client.event.events;
import com.flare.client.event.Event;
/** Fired around ClientPlayerEntity#sendMovementPackets. pre=true before, false after. */
public class MotionEvent extends Event {
    public final boolean pre;
    public MotionEvent(boolean pre) { this.pre = pre; }
}
