package com.flare.client.gui;

import com.flare.client.module.Module;
import com.flare.client.module.modules.client.ClickGuiModule;
import com.flare.client.setting.Setting;
import com.flare.client.util.*;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.List;

public class ModuleButton {
    public static final float H = 18;
    public final Module module; public boolean expanded;
    private final List<SettingComponent> comps = new ArrayList<>();
    private final Anim expandAnim = new Anim(0, 14), toggleAnim = new Anim(0, 14), hoverAnim = new Anim(0, 18);
    public float x, y, w;

    public ModuleButton(Module m) {
        module = m;
        for (Setting<?> s : m.getSettings()) comps.add(SettingComponent.of(s));
        comps.add(SettingComponent.of(m.bind));
    }

    private List<SettingComponent> visible() { List<SettingComponent> l = new ArrayList<>(); for (SettingComponent c : comps) if (c.setting().visible()) l.add(c); return l; }

    public boolean matches(String f) { return f.isEmpty() || module.getName().toLowerCase().contains(f) || module.getDescription().toLowerCase().contains(f); }

    /** Returns height used. */
    public float render(DrawContext ctx, int mx, int my, float x, float y, float w) {
        this.x = x; this.y = y; this.w = w;
        boolean hov = Draw.hover(mx, my, x, y, w, H);
        float on = toggleAnim.update(module.isEnabled() ? 1 : 0), hv = hoverAnim.update(hov ? 1 : 0);
        Draw.glow(ctx, x + 2, y + 1, w - 4, H - 2, 2, ColorUtil.ORANGE, on * 0.9f);
        Draw.rect(ctx, x, y, w, H, ColorUtil.lerp(0xE60E0E0E, 0xFF1C1C1C, hv));
        if (on > 0.01f) {
            Draw.gradH(ctx, x, y, w, H, ColorUtil.alpha(ColorUtil.ORANGE, (int) (150 * on)), ColorUtil.alpha(ColorUtil.ORANGE2, (int) (40 * on)));
            Draw.rect(ctx, x, y, 2, H, ColorUtil.ORANGE2);
        }
        Draw.text(ctx, module.getName(), x + 7 + hv * 1.5f, y + (H - 8) / 2f, ColorUtil.lerp(0xFFBBBBBB, 0xFFFFFFFF, Math.max(on, hv)), on > 0.5f);
        if (!module.getSettings().isEmpty() || true) {
            String ind = expanded ? "-" : "+";
            Draw.text(ctx, ind, x + w - 10, y + (H - 8) / 2f, 0xFF777777, false);
        }
        float total = 0; List<SettingComponent> vis = visible();
        for (SettingComponent c : vis) total += c.h;
        float eh = expandAnim.update(expanded ? total : 0);
        if (eh > 0.5f) {
            ctx.enableScissor(Math.round(x), Math.round(y + H), Math.round(x + w), Math.round(y + H + eh));
            Draw.rect(ctx, x, y + H, w, eh, 0xF2080808);
            Draw.rect(ctx, x + 1, y + H, 1, eh, ColorUtil.alpha(ColorUtil.ORANGE, 120));
            float cy = y + H;
            for (SettingComponent c : vis) { c.x = x + 2; c.y = cy; c.w = w - 2; c.render(ctx, mx, my); cy += c.h; }
            ctx.disableScissor();
        }
        return H + eh;
    }

    public boolean click(double mx, double my, int btn) {
        if (Draw.hover(mx, my, x, y, w, H)) {
            if (btn == 0 && !(module instanceof ClickGuiModule)) module.toggle();
            else if (btn == 1 || module instanceof ClickGuiModule) expanded = !expanded;
            return true;
        }
        if (expanded && expandAnim.get() > 1) for (SettingComponent c : visible()) if (c.click(mx, my, btn)) return true;
        return false;
    }
    public void release() { for (SettingComponent c : comps) c.release(); }
    public void drag(double mx) { for (SettingComponent c : comps) c.drag(mx); }
    public boolean key(int k) { for (SettingComponent c : comps) if (c.key(k)) return true; return false; }
    public boolean isListening() { return module.bind.listening; }
    public String tooltip() { return module.getDescription(); }
    public boolean hoverMain(double mx, double my) { return Draw.hover(mx, my, x, y, w, H); }
}
