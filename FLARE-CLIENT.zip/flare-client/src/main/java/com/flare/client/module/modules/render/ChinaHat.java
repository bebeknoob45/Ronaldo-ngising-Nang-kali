package com.flare.client.module.modules.render;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.Render3DEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.*;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.util.math.Vec3d;

public class ChinaHat extends Module {
    private final ColorSetting color = color("Color", 0xFF6B00);
    private final NumberSetting radius = num("Radius", 0.5, 0.2, 1.0, 0.05);
    public ChinaHat() { super("ChinaHat", "Cosmetic orange hat above your head.", Category.RENDER); }

    @Subscribe
    private void onRender(Render3DEvent e) {
        if (mc.player == null || mc.options.getPerspective().isFirstPerson()) return;
        Vec3d p = mc.player.getLerpedPos(e.delta).add(0, mc.player.getHeight() - 0.02 + (mc.player.isSneaking() ? -0.2 : 0), 0);
        Render3D.begin(true);
        Render3D.fan(e, p, radius.d(), 0.3, 32, ColorUtil.alpha(color.getColor(), 170));
        Render3D.end();
    }
}
