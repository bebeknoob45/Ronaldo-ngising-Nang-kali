package com.flare.client.module.modules.player;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.TickEvent;
import com.flare.client.gui.NotificationManager;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.BoolSetting;
import com.flare.client.setting.NumberSetting;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import net.minecraft.world.GameMode;
import java.util.*;

/**
 * Warns you when someone enters spectator mode (reliable: the server tells every client each player's game mode in the tab list)
 * and, optionally, when a player disappears from the tab list without a leave message (experimental vanish heuristic).
 */
public class AntiVanish extends Module {
    private final BoolSetting spectator = bool("Spectator Detect", true), vanish = bool("Vanish Detect (experimental)", false), chat = bool("Chat Message", true);
    private final NumberSetting range = num("Range (blocks)", 20, 5, 100, 1);
    private final BoolSetting anyDistance = bool("Any Distance", false);
    private final Map<UUID, Vec3d> lastPos = new HashMap<>();
    private final Set<UUID> notified = new HashSet<>();
    private Map<UUID, String> lastTab = new HashMap<>();
    private final Map<String, Long> pendingGone = new HashMap<>();
    private final Deque<Object[]> messages = new ArrayDeque<>();
    private int tick;

    public AntiVanish() { super("AntiVanish", "Warns you when staff spectate or vanish near you.", Category.PLAYER); }

    @Override public void onInit() {
        ClientReceiveMessageEvents.GAME.register((msg, overlay) -> {
            if (!isEnabled()) return;
            messages.add(new Object[]{System.currentTimeMillis(), msg.getString().toLowerCase()});
            while (messages.size() > 60) messages.poll();
        });
    }

    @Override protected void onEnable() { notified.clear(); lastPos.clear(); lastTab = new HashMap<>(); pendingGone.clear(); }

    private void alert(String text) {
        NotificationManager.push("AntiVanish", text, false);
        if (chat.is() && mc.player != null) mc.player.sendMessage(Text.literal("\u00A76[FLARE]\u00A7r " + text), false);
    }

    @Subscribe
    private void onTick(TickEvent.Post e) {
        if (mc.player == null || mc.getNetworkHandler() == null || ++tick % 10 != 0) return;
        Map<UUID, String> now = new HashMap<>(); Set<UUID> spectating = new HashSet<>();
        for (PlayerListEntry en : mc.getNetworkHandler().getPlayerList()) {
            UUID id = en.getProfile().getId(); String name = en.getProfile().getName();
            if (id == null || name == null || id.equals(mc.player.getUuid())) continue;
            now.put(id, name);
            PlayerEntity pe = mc.world == null ? null : mc.world.getPlayerByUuid(id);
            if (pe != null) lastPos.put(id, pe.getPos());
            boolean near = anyDistance.is() || (pe != null && mc.player.distanceTo(pe) <= range.d());
            if (spectator.is() && en.getGameMode() == GameMode.SPECTATOR && near) {
                spectating.add(id);
                if (notified.add(id)) alert(name + " has been watched you, good luck user flare.");
            }
        }
        notified.retainAll(spectating);

        if (vanish.is()) {
            long t = System.currentTimeMillis();
            for (Map.Entry<UUID, String> old : lastTab.entrySet()) if (!now.containsKey(old.getKey())) {
                Vec3d lp = lastPos.get(old.getKey());
                if (anyDistance.is() || (lp != null && lp.distanceTo(mc.player.getPos()) <= range.d())) pendingGone.put(old.getValue(), t);
            }
            pendingGone.keySet().removeIf(n -> now.containsValue(n));
            Iterator<Map.Entry<String, Long>> it = pendingGone.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, Long> g = it.next();
                if (t - g.getValue() < 2500) continue;
                it.remove();
                if (!leftMessage(g.getKey(), g.getValue())) alert(g.getKey() + " has vanished (no leave message) - might be watching you, good luck user flare.");
            }
        }
        lastTab = now;
    }

    private boolean leftMessage(String name, long goneAt) {
        String n = name.toLowerCase();
        for (Object[] m : messages) {
            long time = (Long) m[0]; String s = (String) m[1];
            if (Math.abs(time - goneAt) > 7000 || !s.contains(n)) continue;
            if (s.contains("left") || s.contains("quit") || s.contains("disconnect") || s.contains("leave") || s.contains("logged out") || s.contains("keluar") || s.contains("meninggalkan") || s.contains("\u2190") || s.contains("[-]") || s.contains("- ")) return true;
        }
        return false;
    }
}
