package com.flare.client.mixin;

import com.flare.client.FlareClient;
import com.flare.client.module.modules.render.NoRender;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameOverlayRenderer.class)
public class InGameOverlayRendererMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void flare$fire(CallbackInfo ci) {
        NoRender n = FlareClient.modules == null ? null : FlareClient.modules.get(NoRender.class);
        if (n != null && n.isEnabled() && n.fire.is()) ci.cancel();
    }
    @Inject(method = "renderUnderwaterOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void flare$water(CallbackInfo ci) {
        NoRender n = FlareClient.modules == null ? null : FlareClient.modules.get(NoRender.class);
        if (n != null && n.isEnabled() && n.water.is()) ci.cancel();
    }
    @Inject(method = "renderInWallOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void flare$wall(CallbackInfo ci) {
        NoRender n = FlareClient.modules == null ? null : FlareClient.modules.get(NoRender.class);
        if (n != null && n.isEnabled() && n.wall.is()) ci.cancel();
    }
}
