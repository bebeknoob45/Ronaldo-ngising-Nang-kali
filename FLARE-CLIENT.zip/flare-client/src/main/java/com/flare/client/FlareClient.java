package com.flare.client;

import com.flare.client.config.ConfigManager;
import com.flare.client.event.EventBus;
import com.flare.client.event.events.*;
import com.flare.client.gui.ClickGuiScreen;
import com.flare.client.gui.HudEditorScreen;
import com.flare.client.gui.NotificationManager;
import com.flare.client.module.ModuleManager;
import com.flare.client.util.RotationManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.Camera;
import net.minecraft.text.Text;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FlareClient implements ClientModInitializer {
    public static final String NAME = "FLARE CLIENT", VERSION = "1.5.6";
    public static final Logger LOG = LoggerFactory.getLogger("FlareClient");
    public static final EventBus EVENT_BUS = new EventBus();
    public static ModuleManager modules;

    @Override
    public void onInitializeClient() {
        MinecraftClient mc = MinecraftClient.getInstance();
        FriendManager.load();
        com.flare.client.IdentityManager.load();
        com.flare.client.IdentityManager.applyName();
        modules = new ModuleManager();
        modules.init();
        EVENT_BUS.register(RotationManager.INSTANCE);
        ConfigManager.load("default");

        ClientTickEvents.START_CLIENT_TICK.register(c -> {
            modules.pollKeys();
            if (c.player == null || c.world == null) return;
            EVENT_BUS.post(new TickEvent.Pre());
        });
        ClientTickEvents.END_CLIENT_TICK.register(c -> { if (c.player != null && c.world != null) EVENT_BUS.post(new TickEvent.Post()); });

        HudRenderCallback.EVENT.register((ctx, tc) -> {
            if (mc.player == null) return;
            EVENT_BUS.post(new Render2DEvent(ctx, tc.getTickDelta(false)));
            NotificationManager.render(ctx);
        });

        WorldRenderEvents.LAST.register(ctx -> {
            if (mc.player == null) return;
            Camera cam = ctx.camera();
            Matrix4f view = new Matrix4f().rotation(cam.getRotation().conjugate(new Quaternionf()));
            EVENT_BUS.post(new Render3DEvent(view, cam, ctx.tickCounter().getTickDelta(false)));
        });

        // Pause-menu shortcut (handy for touch / launcher users without Right Shift)
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("FLARE CLIENT"), b -> client.setScreen(new ClickGuiScreen()))
                        .dimensions(6, 6, 100, 20).build());
            }
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> {
            com.flare.client.module.modules.client.FPSBoost fb = modules.get(com.flare.client.module.modules.client.FPSBoost.class);
            if (fb != null) fb.restoreForExit();
            ConfigManager.save("default");
        });
        LOG.info(NAME + " " + VERSION + " loaded");
    }
}
