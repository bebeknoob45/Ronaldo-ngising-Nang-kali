package com.flare.client.event;

import com.flare.client.FlareClient;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/** Lightweight MethodHandle based event bus. Modules only listen while enabled. */
public class EventBus {
    private record Listener(Object owner, MethodHandle handle, int priority) {}
    private final Map<Class<?>, CopyOnWriteArrayList<Listener>> map = new ConcurrentHashMap<>();

    public void register(Object o) {
        for (Class<?> c = o.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                Subscribe s = m.getAnnotation(Subscribe.class);
                if (s == null || m.getParameterCount() != 1) continue;
                try {
                    m.setAccessible(true);
                    MethodHandle h = MethodHandles.lookup().unreflect(m).bindTo(o);
                    CopyOnWriteArrayList<Listener> l = map.computeIfAbsent(m.getParameterTypes()[0], k -> new CopyOnWriteArrayList<>());
                    l.add(new Listener(o, h, s.priority()));
                    l.sort((a, b) -> Integer.compare(b.priority, a.priority));
                } catch (Throwable t) { FlareClient.LOG.error("Failed to register " + m, t); }
            }
        }
    }

    public void unregister(Object o) { map.values().forEach(l -> l.removeIf(x -> x.owner == o)); }

    public <T extends Event> T post(T e) {
        List<Listener> l = map.get(e.getClass());
        if (l != null) for (Listener x : l) {
            try { x.handle.invoke(e); } catch (Throwable t) { FlareClient.LOG.error("Event error", t); }
        }
        return e;
    }
}
