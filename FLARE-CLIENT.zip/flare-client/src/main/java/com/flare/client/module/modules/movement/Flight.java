package com.flare.client.module.modules.movement;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.MoveUtil;
import net.minecraft.util.math.Vec3d;

public class Flight extends Module {
    private final ModeSetting mode = mode("Mode", "Vanilla", "Vanilla", "Glide", "Creative");
    private final NumberSetting speed = num("Speed", 1.0, 0.1, 5, 0.1);
    private final NumberSetting vspeed = (NumberSetting) num("Vertical", 0.6, 0.1, 3, 0.1).visibleIf(() -> mode.is("Vanilla"));
    private final BoolSetting antiKick = bool("Anti Kick", true);
    private int ticks;
    public Flight() { super("Flight", "Lets you fly.", Category.MOVEMENT); }

    @Override protected void onDisable() {
        if (mc.player != null && mode.is("Creative") && !mc.player.isCreative() && !mc.player.isSpectator()) { mc.player.getAbilities().flying = false; mc.player.getAbilities().allowFlying = false; }
    }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        var p = mc.player; if (p == null) return;
        ticks++;
        switch (mode.get()) {
            case "Creative" -> { p.getAbilities().allowFlying = true; p.getAbilities().flying = true; p.getAbilities().setFlySpeed((float) speed.d() * 0.05f); }
            case "Glide" -> { double[] d = MoveUtil.dir(p.getYaw()); double s = speed.d() * 0.3; p.setVelocity(d[0] * s, Math.max(p.getVelocity().y, -0.04), d[1] * s); p.fallDistance = 0; }
            default -> {
                double[] d = MoveUtil.dir(p.getYaw()); double s = speed.d() * 0.5, vy = 0;
                if (mc.options.jumpKey.isPressed()) vy += vspeed.d(); if (mc.options.sneakKey.isPressed()) vy -= vspeed.d();
                if (antiKick.is() && vy == 0 && ticks % 40 == 0) vy = -0.04;
                p.setVelocity(new Vec3d(d[0] * s, vy, d[1] * s)); p.fallDistance = 0;
            }
        }
    }
}
