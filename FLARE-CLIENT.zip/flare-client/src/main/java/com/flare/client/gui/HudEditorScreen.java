package com.flare.client.gui;

import com.flare.client.FlareClient;
import com.flare.client.config.ConfigManager;
import com.flare.client.module.HudModule;
import com.flare.client.module.Module;
import com.flare.client.util.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;

public class HudEditorScreen extends Screen {
    private HudModule dragging; private float ox, oy;
    private final Anim fade = new Anim(0, 12);

    public HudEditorScreen() { super(Text.literal("HUD Editor")); }
    @Override public boolean shouldPause() { return false; }
    @Override public void removed() { ConfigManager.save("default"); }

    private List<HudModule> huds() { List<HudModule> l = new ArrayList<>(); for (Module m : FlareClient.modules.all()) if (m instanceof HudModule h) l.add(h); return l; }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        Draw.alpha = fade.update(1);
        ctx.fill(0, 0, width, height, Draw.fade(0x90000000));
        for (int gx = 0; gx < width; gx += 20) Draw.rect(ctx, gx, 0, 1, height, 0x14FF6B00);
        for (int gy = 0; gy < height; gy += 20) Draw.rect(ctx, 0, gy, width, 1, 0x14FF6B00);
        TopBar.render(ctx, mx, my, width, 1);
        for (HudModule h : huds()) {
            if (!h.isEnabled()) continue;
            h.drawHud(ctx, true);
            boolean hov = Draw.hover(mx, my, h.left() - 3, h.y - 3, h.w + 6, h.h + 6) || dragging == h;
            Draw.outline(ctx, h.left() - 3, h.y - 3, h.w + 6, h.h + 6, ColorUtil.alpha(ColorUtil.ORANGE, hov ? 255 : 120));
            Draw.text(ctx, h.getName(), h.left() - 3, h.y - 13, hov ? 0xFFFFFFFF : 0xFF999999, false);
        }
        // palette
        float x = 10, y = height - 24;
        Draw.text(ctx, "Click to add/remove:", x, y - 12, 0xFFAAAAAA, false);
        for (HudModule h : huds()) {
            float w = Draw.width(h.getName()) + 14;
            Draw.rrect(ctx, x, y, w, 16, 3, h.isEnabled() ? ColorUtil.ORANGE : 0xFF1A1A1A);
            Draw.text(ctx, h.getName(), x + 7, y + 4, h.isEnabled() ? 0xFF0A0A0A : 0xFFFFFFFF, false);
            x += w + 5;
        }
        Draw.text(ctx, "Drag elements to move. Right-click to reset position.", width - 8 - Draw.width("Drag elements to move. Right-click to reset position."), height - 14, 0xFF777777, false);
        Draw.alpha = 1f;
    }

    @Override public boolean mouseClicked(double mx, double my, int btn) {
        Screen s = TopBar.click(mx, my, width, 1);
        if (s != null) { client.setScreen(s); return true; }
        float x = 10, y = height - 24;
        for (HudModule h : huds()) {
            float w = Draw.width(h.getName()) + 14;
            if (Draw.hover(mx, my, x, y, w, 16)) { h.toggle(); return true; }
            x += w + 5;
        }
        List<HudModule> l = huds();
        for (int i = l.size() - 1; i >= 0; i--) {
            HudModule h = l.get(i);
            if (h.isEnabled() && Draw.hover(mx, my, h.left() - 3, h.y - 3, h.w + 6, h.h + 6)) {
                if (btn == 0) { dragging = h; ox = (float) mx - h.left(); oy = (float) my - h.y; }
                else if (btn == 1) h.resetPos();
                return true;
            }
        }
        return false;
    }
    @Override public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (dragging != null) { dragging.setLeft((float) mx - ox); dragging.y = (float) my - oy; }
        return true;
    }
    @Override public boolean mouseReleased(double mx, double my, int btn) { dragging = null; return true; }
    @Override public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
