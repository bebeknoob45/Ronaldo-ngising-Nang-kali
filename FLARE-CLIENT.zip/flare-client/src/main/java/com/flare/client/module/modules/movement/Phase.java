package com.flare.client.module.modules.movement;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.*;
import net.minecraft.util.math.Vec3d;

public class Phase extends Module {
    private final ModeSetting mode = mode("Mode", "Clip", "Clip", "NoClip");
    private final NumberSetting distance = (NumberSetting) num("Distance", 2, 1, 10, 0.5).visibleIf(() -> mode.is("Clip"));
    private final NumberSetting speed = (NumberSetting) num("Speed", 0.6, 0.1, 3, 0.1).visibleIf(() -> mode.is("NoClip"));
    public Phase() { super("Phase", "Clip through blocks (Clip) or move freely inside them (NoClip).", Category.MOVEMENT); }
    public boolean isNoClip() { return isEnabled() && mode.is("NoClip"); }

    @Override protected void onEnable() {
        if (mc.player == null || !mode.is("Clip")) return;
        double[] d = MoveUtil.dir(mc.player.getYaw());
        if (d[0] == 0 && d[1] == 0) { Vec3d l = Vec3d.fromPolar(0, mc.player.getYaw()); d = new double[]{l.x, l.z}; }
        double x = mc.player.getX() + d[0] * distance.d(), z = mc.player.getZ() + d[1] * distance.d(), y = mc.player.getY();
        PacketUtil.pos(mc.player.getX() + d[0] * 0.2, y, mc.player.getZ() + d[1] * 0.2, false);
        PacketUtil.pos(x, y, z, mc.player.isOnGround());
        mc.player.setPosition(x, y, z);
        setEnabled(false, true);
    }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        if (!isNoClip() || mc.player == null) return;
        double[] d = MoveUtil.dir(mc.player.getYaw()); double vy = 0;
        if (mc.options.jumpKey.isPressed()) vy += speed.d(); if (mc.options.sneakKey.isPressed()) vy -= speed.d();
        mc.player.setVelocity(d[0] * speed.d(), vy, d[1] * speed.d()); mc.player.fallDistance = 0;
    }
}
