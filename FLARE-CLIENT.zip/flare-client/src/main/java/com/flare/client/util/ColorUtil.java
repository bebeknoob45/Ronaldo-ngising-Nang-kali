package com.flare.client.util;
import java.awt.Color;
public final class ColorUtil {
    public static final int ORANGE = 0xFFFF6B00, ORANGE2 = 0xFFFF8C00;
    public static int alpha(int c, int a) { return (c & 0xFFFFFF) | (Math.max(0, Math.min(255, a)) << 24); }
    public static int lerp(int a, int b, float t) {
        t = Math.max(0, Math.min(1, t));
        int r = 0;
        for (int s = 0; s <= 24; s += 8) {
            int x = (a >>> s) & 255, y = (b >>> s) & 255;
            r |= ((int) (x + (y - x) * t) & 255) << s;
        }
        return r;
    }
    public static int rainbow(float speed, float offset, int a) {
        float h = ((System.currentTimeMillis() / (1000f / speed * 3f)) + offset) % 1f;
        return (a << 24) | (Color.HSBtoRGB(h, 0.85f, 1f) & 0xFFFFFF);
    }
    /** Animated orange gradient used across the UI. */
    public static int flame(float offset) {
        return lerp(ORANGE, ORANGE2, (float) (Math.sin(System.currentTimeMillis() / 500.0 + offset) * 0.5 + 0.5));
    }
}
