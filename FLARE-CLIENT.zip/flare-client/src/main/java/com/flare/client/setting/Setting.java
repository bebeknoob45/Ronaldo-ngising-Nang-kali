package com.flare.client.setting;
import com.google.gson.JsonElement;
import java.util.function.Supplier;
public abstract class Setting<T> {
    public final String name; protected T value; public final T def;
    private Supplier<Boolean> vis = () -> true;
    public Setting(String name, T def) { this.name = name; this.value = def; this.def = def; }
    public T get() { return value; }
    public void set(T v) { value = v; }
    public Setting<T> visibleIf(Supplier<Boolean> s) { vis = s; return this; }
    public boolean visible() { return vis.get(); }
    public abstract JsonElement save();
    public abstract void load(JsonElement e);
}
