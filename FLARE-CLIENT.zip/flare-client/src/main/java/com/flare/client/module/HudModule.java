package com.flare.client.module;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.Render2DEvent;
import com.flare.client.gui.ClickGuiScreen;
import com.flare.client.gui.ConfigScreen;
import com.flare.client.gui.HudEditorScreen;
import com.google.gson.JsonObject;
import net.minecraft.client.gui.DrawContext;

/** Base for draggable HUD elements. */
public abstract class HudModule extends Module {
    public float x, y, w = 60, h = 12;
    protected final float defX, defY;
    protected HudModule(String name, String desc, float x, float y) { super(name, desc, Category.RENDER); this.x = defX = x; this.y = defY = y; }

    public abstract void drawHud(DrawContext ctx, boolean editing);
    public float left() { return x; }
    public void setLeft(float l) { x = l; }
    public void resetPos() { x = defX; y = defY; }

    @Subscribe
    private void onRender2D(Render2DEvent e) {
        if (mc.options.hudHidden) return;
        if (mc.currentScreen instanceof HudEditorScreen || mc.currentScreen instanceof ClickGuiScreen || mc.currentScreen instanceof ConfigScreen) return;
        drawHud(e.ctx, false);
    }
    @Override public void onSave(JsonObject o) { o.addProperty("x", x); o.addProperty("y", y); }
    @Override public void onLoad(JsonObject o) { if (o.has("x")) x = o.get("x").getAsFloat(); if (o.has("y")) y = o.get("y").getAsFloat(); }
}
