package com.flare.client.module.modules.player;

import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.NumberSetting;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;

public class AutoReconnect extends Module {
    private final NumberSetting delay = num("Delay (s)", 5, 1, 30, 1);
    private ServerInfo last;
    public AutoReconnect() { super("AutoReconnect", "Reconnects automatically after being disconnected.", Category.PLAYER); }

    @Override public void onInit() {
        ClientPlayConnectionEvents.JOIN.register((h, s, c) -> { if (mc.getCurrentServerEntry() != null) last = mc.getCurrentServerEntry(); });
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (!(screen instanceof DisconnectedScreen) || !isEnabled() || last == null) return;
            final long end = System.currentTimeMillis() + (long) (delay.d() * 1000);
            final boolean[] fired = {false};
            ScreenEvents.afterRender(screen).register((s, ctx, mx, my, td) -> {
                if (!isEnabled() || last == null) return;
                long left = end - System.currentTimeMillis();
                String t = "FLARE: reconnecting in " + Math.max(0, left / 1000 + 1) + "s  (close screen to cancel)";
                ctx.drawCenteredTextWithShadow(mc.textRenderer, t, s.width / 2, 12, 0xFFFF6B00);
                if (left <= 0 && !fired[0]) {
                    fired[0] = true;
                    ConnectScreen.connect(new TitleScreen(), mc, ServerAddress.parse(last.address), last, false, null);
                }
            });
        });
    }
}
