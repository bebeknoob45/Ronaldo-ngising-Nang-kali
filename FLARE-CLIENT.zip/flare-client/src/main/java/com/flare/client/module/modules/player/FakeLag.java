package com.flare.client.module.modules.player;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.AttackEvent;
import com.flare.client.event.events.PacketEvent;
import com.flare.client.event.events.TickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.*;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import java.util.ArrayDeque;
import java.util.Queue;

public class FakeLag extends Module {
    private final NumberSetting lag = num("Lag (ms)", 250, 50, 1000, 10);
    private final BoolSetting flushOnAttack = bool("Flush On Attack", true), flushOnHurt = bool("Flush On Hurt", true);
    private final Queue<Packet<?>> queue = new ArrayDeque<>(); private final TimerUtil timer = new TimerUtil(); private int lastHurt;
    public FakeLag() { super("FakeLag", "Intermittently delays your movement packets.", Category.PLAYER); }
    @Override protected void onDisable() { flush(); }

    @Subscribe private void onSend(PacketEvent.Send e) { if (e.packet instanceof PlayerMoveC2SPacket) { queue.add(e.packet); e.cancel(); } }
    @Subscribe private void onAttack(AttackEvent e) { if (flushOnAttack.is()) flush(); }
    @Subscribe private void onTick(TickEvent.Post e) {
        if (mc.player == null) return;
        boolean hurt = flushOnHurt.is() && mc.player.hurtTime > 0 && mc.player.hurtTime != lastHurt;
        lastHurt = mc.player.hurtTime;
        if (hurt || timer.hasReached((long) lag.d())) flush();
    }
    private void flush() { while (!queue.isEmpty()) PacketUtil.sendSilent(queue.poll()); timer.reset(); }
}
