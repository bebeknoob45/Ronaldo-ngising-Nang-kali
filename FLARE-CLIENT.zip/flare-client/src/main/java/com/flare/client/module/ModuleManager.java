package com.flare.client.module;

import com.flare.client.module.modules.client.*;
import com.flare.client.module.modules.combat.*;
import com.flare.client.module.modules.movement.*;
import com.flare.client.module.modules.player.*;
import com.flare.client.module.modules.render.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import java.util.*;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    private final Map<Class<?>, Module> byClass = new HashMap<>();
    private final Map<Module, Boolean> keyState = new HashMap<>();

    public void init() {
        // Combat
        reg(new KillAura()); reg(new Criticals()); reg(new AutoCrystal()); reg(new Velocity()); reg(new AutoTotem());
        reg(new AutoArmor()); reg(new Surround()); reg(new AutoTrap()); reg(new HoleFiller()); reg(new BowAimbot()); reg(new Reach());
        // Movement
        reg(new Speed()); reg(new Flight()); reg(new Scaffold()); reg(new Step()); reg(new LongJump()); reg(new NoSlow());
        reg(new Sprint()); reg(new Jesus()); reg(new Phase());
        // Render
        reg(new ESPBlock()); reg(new ESPPlayer()); reg(new ESPStorage()); reg(new Freecam()); reg(new Nametags()); reg(new Fullbright()); reg(new NoRender());
        reg(new ArrayListHud()); reg(new Watermark()); reg(new TargetHud()); reg(new Crosshair()); reg(new ChinaHat());
        // Player
        reg(new AutoReconnect()); reg(new AntiAFK()); reg(new Blink()); reg(new FakeLag()); reg(new InventoryManager());
        reg(new MiddleClick()); reg(new ChatSuffix()); reg(new AntiVanish());
        // Client
        reg(new ClickGuiModule()); reg(new DiscordRPC()); reg(new FPSBoost());
        modules.forEach(Module::onInit);
    }

    private void reg(Module m) { modules.add(m); byClass.put(m.getClass(), m); }
    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> c) { return (T) byClass.get(c); }
    public Module get(String name) { for (Module m : modules) if (m.getName().equalsIgnoreCase(name)) return m; return null; }
    public List<Module> all() { return modules; }
    public List<Module> inCategory(Category c) { List<Module> l = new ArrayList<>(); for (Module m : modules) if (m.getCategory() == c) l.add(m); return l; }

    public void pollKeys() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getWindow() == null) return;
        long h = mc.getWindow().getHandle();
        for (Module m : modules) {
            int k = m.bind.key();
            if (k < 0) continue;
            boolean down = InputUtil.isKeyPressed(h, k), prev = keyState.getOrDefault(m, false);
            keyState.put(m, down);
            if (down && !prev && mc.currentScreen == null) m.toggle();
        }
    }
}
