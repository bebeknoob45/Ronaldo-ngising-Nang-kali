package com.flare.client.module.modules.combat;

import com.flare.client.event.Subscribe;
import com.flare.client.event.events.MotionEvent;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.Category;
import com.flare.client.module.Module;
import com.flare.client.setting.*;
import com.flare.client.util.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.*;

public class KillAura extends Module {
    private final ModeSetting mode = mode("Mode", "Single", "Single", "Switch", "Multi");
    private final NumberSetting range = num("Range", 3.8, 2, 6, 0.1);
    private final BoolSetting walls = bool("Through Walls", false);
    private final ModeSetting priority = mode("Priority", "Distance", "Distance", "Health", "Angle", "Armor");
    private final ModeSetting timing = mode("Timing", "Cooldown", "Cooldown", "CPS");
    private final NumberSetting minCps = (NumberSetting) num("Min CPS", 8, 1, 20, 1).visibleIf(() -> timing.is("CPS"));
    private final NumberSetting maxCps = (NumberSetting) num("Max CPS", 12, 1, 20, 1).visibleIf(() -> timing.is("CPS"));
    private final ModeSetting rotations = mode("Rotations", "Silent", "None", "Silent", "Snap", "Lock");
    private final NumberSetting rotSpeed = (NumberSetting) num("Rot Speed", 55, 5, 180, 1).visibleIf(() -> rotations.is("Silent") || rotations.is("Lock"));
    private final NumberSetting multiMax = (NumberSetting) num("Multi Targets", 3, 1, 8, 1).visibleIf(() -> mode.is("Multi"));
    private final BoolSetting players = bool("Players", true), mobs = bool("Mobs", false), animals = bool("Animals", false), invis = bool("Invisible", true);
    private final NumberSetting fov = num("FOV", 360, 30, 360, 1);
    private final BoolSetting weaponOnly = bool("Weapon Only", false);

    private final TimerUtil timer = new TimerUtil(); private long delay = 100; private int switchIdx;
    private final Random rnd = new Random();
    private LivingEntity target; private List<LivingEntity> attackList = new ArrayList<>();
    public KillAura() { super("KillAura", "Automatically attacks nearby targets.", Category.COMBAT); }
    public LivingEntity getTarget() { return target; }
    @Override protected void onDisable() { target = null; attackList.clear(); }
    @Override public String getSuffix() { return mode.get(); }

    @Subscribe
    private void onTick(PlayerTickEvent e) {
        target = null; attackList.clear();
        if (mc.player == null || mc.world == null || mc.player.isDead()) return;
        if (weaponOnly.is() && !isWeapon(mc.player.getMainHandStack())) return;
        List<LivingEntity> list = targets();
        if (list.isEmpty()) return;
        if (mode.is("Switch")) target = list.get(switchIdx % list.size()); else target = list.get(0);
        if (mode.is("Multi")) attackList.addAll(list.subList(0, Math.min(list.size(), multiMax.i()))); else attackList.add(target);

        if (!rotations.is("None")) {
            Vec3d eye = mc.player.getEyePos(), aim = CombatUtil.aimPoint(target).add((rnd.nextDouble() - 0.5) * 0.06, (rnd.nextDouble() - 0.5) * 0.06, (rnd.nextDouble() - 0.5) * 0.06);
            float[] t = RotationManager.toRotation(eye, aim);
            RotationManager rm = RotationManager.INSTANCE;
            float cy = rm.isActive() ? rm.curYaw() : mc.player.getYaw(), cp = rm.isActive() ? rm.curPitch() : mc.player.getPitch();
            float[] r = rotations.is("Snap") ? t : RotationManager.smooth(cy, cp, t[0], t[1], rotSpeed.f() + (rnd.nextFloat() - 0.5f) * 8f);
            r = RotationManager.gcd(r, rm.serverYaw, rm.serverPitch);
            if (rotations.is("Lock")) { mc.player.setYaw(r[0]); mc.player.setPitch(r[1]); } else rm.rotate(r[0], r[1], 1);
        }
    }

    @Subscribe
    private void onMotion(MotionEvent e) {
        if (e.pre || target == null || attackList.isEmpty() || mc.player == null) return;
        boolean ready = timing.is("Cooldown") ? mc.player.getAttackCooldownProgress(0.5f) >= 0.95f && timer.hasReached(50) : timer.hasReached(delay);
        if (!ready) return;
        float yaw = rotations.is("None") ? mc.player.getYaw() : RotationManager.INSTANCE.serverYaw, pitch = rotations.is("None") ? mc.player.getPitch() : RotationManager.INSTANCE.serverPitch;
        boolean hit = false;
        for (LivingEntity t : attackList) {
            if (!rotations.is("None") && t == target && !CombatUtil.lookingAt(yaw, pitch, t, range.d() + 0.3)) continue;
            mc.interactionManager.attackEntity(mc.player, t); hit = true;
        }
        if (hit) {
            mc.player.swingHand(Hand.MAIN_HAND);
            timer.reset(); switchIdx++;
            if (timing.is("CPS")) { double cps = minCps.d() + rnd.nextDouble() * Math.max(0, maxCps.d() - minCps.d()); delay = (long) (1000.0 / cps + rnd.nextInt(12)); }
        }
    }

    private List<LivingEntity> targets() {
        List<LivingEntity> l = new ArrayList<>(); Vec3d eye = mc.player.getEyePos();
        for (Entity en : mc.world.getEntities()) {
            if (!CombatUtil.validLiving(en) || !(en instanceof LivingEntity le)) continue;
            if (!validType(le) || CombatUtil.isFriend(le)) continue;
            if (CombatUtil.distanceToBox(eye, le.getBoundingBox()) > range.d()) continue;
            if (!walls.is() && !CombatUtil.canSee(le)) continue;
            if (fov.d() < 360) {
                float[] r = RotationManager.toRotation(eye, le.getBoundingBox().getCenter());
                if (Math.abs(MathHelper.wrapDegrees(r[0] - mc.player.getYaw())) > fov.d() / 2) continue;
            }
            l.add(le);
        }
        l.sort(Comparator.comparingDouble(this::score));
        return l;
    }
    private double score(LivingEntity e) {
        return switch (priority.get()) {
            case "Health" -> e.getHealth() + e.getAbsorptionAmount();
            case "Armor" -> e.getArmor();
            case "Angle" -> Math.abs(MathHelper.wrapDegrees(RotationManager.toRotation(mc.player.getEyePos(), e.getBoundingBox().getCenter())[0] - mc.player.getYaw()));
            default -> mc.player.distanceTo(e);
        };
    }
    private boolean validType(LivingEntity e) {
        if (e.isInvisible() && !invis.is()) return false;
        if (e instanceof PlayerEntity) return players.is();
        if (e instanceof AnimalEntity) return animals.is();
        if (e instanceof Monster) return mobs.is();
        return false;
    }
    private boolean isWeapon(ItemStack s) { return s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES); }
}
