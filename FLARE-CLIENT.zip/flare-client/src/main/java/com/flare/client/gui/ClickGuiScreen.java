package com.flare.client.gui;

import com.flare.client.FlareClient;
import com.flare.client.module.Category;
import com.flare.client.module.modules.client.ClickGuiModule;
import com.flare.client.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.*;

public class ClickGuiScreen extends Screen {
    public static final List<Panel> PANELS = new ArrayList<>();
    private final Anim openAnim = new Anim(0, 10);
    private boolean closing; private String search = ""; private float scroll, maxScroll;
    private final List<float[]> embers = new ArrayList<>();
    private final Random rnd = new Random();
    private Panel dragging;

    public ClickGuiScreen() { super(Text.literal("FLARE CLIENT")); }

    @Override protected void init() {
        if (PANELS.isEmpty()) {
            float pw = Math.max(84, Math.min(116, (width - 40) / 5f - 6));
            float x = 10;
            for (Category c : Category.values()) { Panel p = new Panel(c, x, 38); p.w = pw; PANELS.add(p); x += pw + 8; }
        }
        scroll = 0;
        if (embers.isEmpty()) for (int i = 0; i < 55; i++) embers.add(new float[]{rnd.nextFloat(), rnd.nextFloat(), 0.02f + rnd.nextFloat() * 0.05f, 1 + rnd.nextInt(2), rnd.nextFloat()});
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void close() { closing = true; }
    @Override public void removed() {
        ClickGuiModule m = FlareClient.modules.get(ClickGuiModule.class);
        if (m != null) { ClickGuiModule.suppress = true; try { m.setEnabled(false, false); } finally { ClickGuiModule.suppress = false; } }
    }
    private String filter() { return search.toLowerCase(); }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        float a = openAnim.update(closing ? 0 : 1);
        if (closing && a <= 0.02f) { MinecraftClient.getInstance().setScreen(null); return; }
        Draw.alpha = a;
        ClickGuiModule cfg = FlareClient.modules.get(ClickGuiModule.class);
        ctx.fill(0, 0, width, height, Draw.fade(0xB4000000));
        ctx.fillGradient(0, height / 2, width, height, 0x00FF6B00, Draw.fade(0x38FF6B00));
        if (cfg == null || cfg.particles.is()) renderEmbers(ctx);

        TopBar.render(ctx, mx, my, width, 0);
        // search bar
        float sw = Math.min(150, width * 0.3f), sx = width / 2f - sw / 2f - 30;
        Draw.rrect(ctx, sx, 8, sw, 16, 3, 0xFF161616);
        Draw.outline(ctx, sx, 8, sw, 16, ColorUtil.alpha(ColorUtil.ORANGE, search.isEmpty() ? 90 : 220));
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        Draw.text(ctx, search.isEmpty() ? "Search modules..." : search + (blink ? "_" : ""), sx + 6, 12, search.isEmpty() ? 0xFF666666 : 0xFFFFFFFF, false);

        float slideBase = (1f - a) * -30f;
        float maxB = 0; int i = 0;
        for (Panel p : PANELS) {
            p.render(ctx, mx, my, scroll, filter(), slideBase - i * 3f * (1f - a));
            if (p.lastHeight > 0 || filter().isEmpty()) maxB = Math.max(maxB, p.bottom(0));
            i++;
        }
        maxScroll = Math.max(0, maxB - height + 30);
        scroll = Math.max(-maxScroll, Math.min(0, scroll));

        // tooltip
        for (Panel p : PANELS) for (ModuleButton b : p.buttons) if (b.hoverMain(mx, my)) {
            String t = b.tooltip(); float w = Draw.width(t) + 10;
            float tx = Math.min(width - w - 4, mx + 10), ty = my + 12;
            Draw.rrect(ctx, tx, ty, w, 14, 3, 0xF0000000); Draw.outline(ctx, tx, ty, w, 14, ColorUtil.alpha(ColorUtil.ORANGE, 200));
            Draw.text(ctx, t, tx + 5, ty + 3, 0xFFFFFFFF, false);
        }
        Draw.alpha = 1f;
    }

    private void renderEmbers(DrawContext ctx) {
        long t = System.currentTimeMillis();
        for (float[] e : embers) {
            e[1] -= e[2] * 0.016f * 2f; if (e[1] < -0.02f) { e[1] = 1.02f; e[0] = rnd.nextFloat(); }
            float x = e[0] * width + (float) Math.sin(t / 900.0 + e[4] * 6) * 6, y = e[1] * height;
            int al = (int) (110 * Math.min(1f, e[1] + 0.2f));
            Draw.rect(ctx, x, y, e[3], e[3], ColorUtil.alpha(e[4] > 0.5f ? ColorUtil.ORANGE : ColorUtil.ORANGE2, al));
        }
    }

    @Override public boolean mouseClicked(double mx, double my, int btn) {
        if (openAnim.get() < 0.9f) return true;
        Screen s = TopBar.click(mx, my, width, 0);
        if (s != null) { client.setScreen(s); return true; }
        for (int i = PANELS.size() - 1; i >= 0; i--) {
            Panel p = PANELS.get(i);
            if (p.click(mx, my, btn, scroll)) { PANELS.remove(i); PANELS.add(p); dragging = p; return true; }
        }
        return super.mouseClicked(mx, my, btn);
    }
    @Override public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        for (Panel p : PANELS) p.drag(mx, my - scroll * 0);
        return true;
    }
    @Override public boolean mouseReleased(double mx, double my, int btn) { for (Panel p : PANELS) p.release(); dragging = null; return true; }
    @Override public boolean mouseScrolled(double mx, double my, double h, double v) { scroll += (float) v * 22f; return true; }

    @Override public boolean keyPressed(int key, int scan, int mods) {
        for (Panel p : PANELS) if (p.listening()) { p.key(key); return true; }
        if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        if (key == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) { search = search.substring(0, search.length() - 1); return true; }
        return super.keyPressed(key, scan, mods);
    }
    @Override public boolean charTyped(char c, int mods) {
        if (search.length() < 20 && c >= 32) { search += c; return true; }
        return false;
    }
}
