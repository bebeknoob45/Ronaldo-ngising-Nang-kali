package com.flare.client.mixin;

import com.flare.client.FlareClient;
import com.flare.client.event.events.MotionEvent;
import com.flare.client.event.events.PlayerTickEvent;
import com.flare.client.module.modules.movement.NoSlow;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void flare$tick(CallbackInfo ci) { FlareClient.EVENT_BUS.post(new PlayerTickEvent()); }

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void flare$motionPre(CallbackInfo ci) { FlareClient.EVENT_BUS.post(new MotionEvent(true)); }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"))
    private void flare$motionPost(CallbackInfo ci) { FlareClient.EVENT_BUS.post(new MotionEvent(false)); }

    @Redirect(method = "tickMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z"), require = 0)
    private boolean flare$noSlow(ClientPlayerEntity self) {
        NoSlow n = FlareClient.modules == null ? null : FlareClient.modules.get(NoSlow.class);
        return (n == null || !n.isEnabled()) && self.isUsingItem();
    }
}
