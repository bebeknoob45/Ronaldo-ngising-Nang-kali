package com.flare.client.gui;

import com.flare.client.setting.*;
import com.flare.client.util.*;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

public abstract class SettingComponent {
    protected final Setting<?> setting;
    public float x, y, w; public float h = 15;
    protected final Anim anim = new Anim(0, 16);
    protected SettingComponent(Setting<?> s) { setting = s; }
    public Setting<?> setting() { return setting; }
    public abstract void render(DrawContext ctx, int mx, int my);
    public boolean click(double mx, double my, int btn) { return false; }
    public void release() {}
    public void drag(double mx) {}
    public boolean key(int key) { return false; }
    protected boolean hover(double mx, double my) { return Draw.hover(mx, my, x, y, w, h); }

    public static SettingComponent of(Setting<?> s) {
        if (s instanceof BoolSetting b) return new Bool(b);
        if (s instanceof NumberSetting n) return new Num(n);
        if (s instanceof ModeSetting m) return new Mode(m);
        if (s instanceof ColorSetting c) return new Col(c);
        if (s instanceof KeybindSetting k) return new Bind(k);
        throw new IllegalArgumentException();
    }

    static class Bool extends SettingComponent {
        final BoolSetting s;
        Bool(BoolSetting s) { super(s); this.s = s; }
        public void render(DrawContext ctx, int mx, int my) {
            float t = anim.update(s.is() ? 1 : 0);
            Draw.text(ctx, s.name, x + 6, y + 3.5f, ColorUtil.lerp(0xFFB0B0B0, 0xFFFFFFFF, t), false);
            float bx = x + w - 16, by = y + 3.5f;
            Draw.glow(ctx, bx, by, 9, 9, 2, ColorUtil.ORANGE, t * 0.8f);
            Draw.rrect(ctx, bx, by, 9, 9, 2, ColorUtil.lerp(0xFF2A2A2A, ColorUtil.ORANGE, t));
            if (t > 0.5f) Draw.rect(ctx, bx + 3, by + 3, 3, 3, 0xFF0A0A0A);
        }
        public boolean click(double mx, double my, int b) { if (hover(mx, my) && b == 0) { s.toggle(); return true; } return false; }
    }

    static class Num extends SettingComponent {
        final NumberSetting s; boolean dragging;
        Num(NumberSetting s) { super(s); this.s = s; h = 17; }
        public void render(DrawContext ctx, int mx, int my) {
            float frac = (float) ((s.d() - s.min) / (s.max - s.min));
            float t = anim.update(frac);
            Draw.rect(ctx, x + 4, y + h - 5, w - 8, 2, 0xFF262626);
            Draw.gradH(ctx, x + 4, y + h - 5, (w - 8) * t, 2, ColorUtil.ORANGE, ColorUtil.ORANGE2);
            Draw.rect(ctx, x + 4 + (w - 8) * t - 1.5f, y + h - 7, 3, 6, 0xFFFFFFFF);
            Draw.text(ctx, s.name, x + 6, y + 2, 0xFFB0B0B0, false);
            String v = (s.step >= 1 ? String.valueOf(s.i()) : String.format("%.2f", s.d()));
            Draw.text(ctx, v, x + w - 6 - Draw.width(v), y + 2, ColorUtil.ORANGE2, false);
        }
        public boolean click(double mx, double my, int b) { if (hover(mx, my) && b == 0) { dragging = true; drag(mx); return true; } return false; }
        public void drag(double mx) { if (dragging) s.set(s.min + MathHelperClamp((mx - (x + 4)) / (w - 8)) * (s.max - s.min)); }
        public void release() { dragging = false; }
        private static double MathHelperClamp(double d) { return Math.max(0, Math.min(1, d)); }
    }

    static class Mode extends SettingComponent {
        final ModeSetting s;
        Mode(ModeSetting s) { super(s); this.s = s; }
        public void render(DrawContext ctx, int mx, int my) {
            Draw.text(ctx, s.name, x + 6, y + 3.5f, 0xFFB0B0B0, false);
            Draw.text(ctx, s.get(), x + w - 6 - Draw.width(s.get()), y + 3.5f, ColorUtil.ORANGE2, false);
        }
        public boolean click(double mx, double my, int b) { if (hover(mx, my) && (b == 0 || b == 1)) { s.cycle(b == 0); return true; } return false; }
    }

    static class Col extends SettingComponent {
        final ColorSetting s; boolean dragging;
        Col(ColorSetting s) { super(s); this.s = s; }
        public void render(DrawContext ctx, int mx, int my) {
            Draw.text(ctx, s.name, x + 6, y + 3.5f, 0xFFB0B0B0, false);
            float bx = x + w - 66, bw = 54;
            for (int i = 0; i < 27; i++) Draw.rect(ctx, bx + i * bw / 27f, y + 4, bw / 27f + 1, 7, 0xFF000000 | (java.awt.Color.HSBtoRGB(i / 27f, 1, 1) & 0xFFFFFF));
            Draw.rect(ctx, bx + s.h * bw - 1, y + 2, 2, 11, 0xFFFFFFFF);
            Draw.rrect(ctx, x + w - 10, y + 4, 7, 7, 2, s.getColor() | 0xFF000000);
        }
        public boolean click(double mx, double my, int b) {
            if (!hover(mx, my)) return false;
            if (b == 1) { s.rainbow = !s.rainbow; return true; }
            if (b == 0) { dragging = true; drag(mx); return true; }
            return false;
        }
        public void drag(double mx) { if (dragging) { float bx = x + w - 66; s.h = (float) Math.max(0, Math.min(1, (mx - bx) / 54)); s.rainbow = false; } }
        public void release() { dragging = false; }
    }

    static class Bind extends SettingComponent {
        final KeybindSetting s;
        Bind(KeybindSetting s) { super(s); this.s = s; }
        public void render(DrawContext ctx, int mx, int my) {
            String v = s.listening ? "..." : KeyUtil.name(s.key());
            Draw.text(ctx, "Bind", x + 6, y + 3.5f, 0xFFB0B0B0, false);
            Draw.text(ctx, "[" + v + "]", x + w - 6 - Draw.width("[" + v + "]"), y + 3.5f, s.listening ? 0xFFFFFFFF : ColorUtil.ORANGE2, false);
        }
        public boolean click(double mx, double my, int b) { if (hover(mx, my) && b == 0) { s.listening = !s.listening; return true; } return false; }
        public boolean key(int key) {
            if (!s.listening) return false;
            if (key == GLFW.GLFW_KEY_ESCAPE) { s.listening = false; return true; }
            s.set(key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE ? -1 : key); s.listening = false; return true;
        }
    }
}
